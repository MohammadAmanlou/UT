/*
* 2021 Fall
* Computer Assginment 2 Phase 1
*/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Constants
#define MAX_STUDENTS 10
#define MAX_FOOD 10
#define MAX_COUPONS 10
#define MAX_HALL 10
#define MAX_COMMAND_LENGTH 1000
#define FALSE 0
#define TRUE 1
#define NOT_SIGNED_IN -1
#define ADMIN_ID -2
#define USERS_PATH "users.txt"
#define MAX_STR_LEN 100

#define SIGNUP "signup"
#define LOGIN "login"
#define LOGOUT "logout"
#define ADD_HALL "add_hall"
#define ADD_FOOD "add_food"
#define ADD_COUPON "add_coupon"


// Define Struct
typedef struct {
    char username[MAX_STR_LEN];
    int student_id;
    char password[MAX_STR_LEN];
} Student;

typedef struct {
    char name[MAX_STR_LEN];
    int hall_id;
    int capacity;
} Hall;

typedef struct {
    char name[MAX_STR_LEN];
    int food_id;
    int price;
    int capacity;
    int hall_id;
    int day;
} Food;

typedef struct {
    int coupon_id;
    int percentage;
    int capacity;
} Coupon;


void print_welcome(char username[MAX_STR_LEN])
{
    printf("%s","welcome ");
    printf("%s",username);
    printf("%s","\n");
}

void print_done()
{
    printf("%s","done\n");
}

void print_user_already_exists()
{
    printf("%s","user already exists\n");
}

void print_wrong_user_pass()
{
    printf("%s","wrong username or pass\n");
}

void print_access_denied()
{
    printf("%s","access denied\n");
}

void print_not_unique_hall_id()
{
    printf("%s","hall id is not unique\n");
}

void print_not_unique_food_id()
{
    printf("%s","food id is not unique\n");
}

void print_not_unique_coupon_id()
{
    printf("%s","coupon id is not unique\n");
}

void print_wrong_hall_id()
{
    printf("%s","wrong hall id\n");
}

int is_empty(char *str)
{
    if(strlen(str) <= 1)
        return TRUE;
    else
        return FALSE;
}

void save_new_user(char username[MAX_STR_LEN],int student_id,char password[MAX_STR_LEN])
{
    char str[MAX_COMMAND_LENGTH];

    char student_id_string[MAX_STR_LEN];
    sprintf(student_id_string, "%d", student_id);

    strcpy(str, username);
    strcat(str, " ");
    strcat(str, student_id_string);
    strcat(str, " ");
    strcat(str, password);
    strcat(str, "\n");
    
    // Saving the result
    FILE * fptr;
    fptr = fopen(USERS_PATH,"a"); 
    fputs(str, fptr);
    fclose (fptr);
}

// Returns true if the signup is successful
int signup(char username[MAX_STR_LEN],int student_id,char password[MAX_STR_LEN],Student *students,int last_student_index,int save_result)
{
    for(int j = 0; j <= last_student_index;j++)
    {
        // Check whether username or student_id exists
        if(strcmp(students[j].username,username) == 0 || students[j].student_id == student_id )
            return FALSE;
    }

    strcpy(students[last_student_index + 1].username,username);
    strcpy(students[last_student_index + 1].password,password);
    students[last_student_index + 1].student_id = student_id;

    if(save_result == TRUE)
        save_new_user(username,student_id,password);

    return TRUE;
}

// This function tokenizes signup command
int signup_command(char cmd[MAX_COMMAND_LENGTH],Student* students,int last_student_index)
{
    char* token = strtok(cmd, " ");
    //Skip the first token
    token = strtok(NULL, " ");
    
    char username[MAX_STR_LEN];
    int student_id;
    char password[MAX_STR_LEN];

    int i = 0;
    while (token) {

        switch(i)
        {
            case 0:
                strcpy(username,token);
                break;
            case 1:
                student_id = atoi(token);
                break;
            case 2:
                strcpy(password,token);
                break;
        }

        i += 1;
        token = strtok(NULL, " ");
    }

    int save_result = TRUE;
    return signup(username,student_id,password,students,last_student_index,save_result);
}

// Returns student_id if the username & password is correct otherwise it returns FALSE
int login(char username[MAX_STR_LEN],char password[MAX_STR_LEN],Student* students,int last_student_index)
{

    // Check if the entered user & pass are admin or not
    char admin[MAX_STR_LEN] = "admin";
    if(strcmp(username,admin) == 0 && strcmp(password,admin) == 0)
    {
        print_welcome(username);
        return ADMIN_ID;
    }

    // Iterate through students array
    for(int j = 0; j <= last_student_index;j++)
    {
        if(strcmp(students[j].username,username) == 0 && strcmp(students[j].password,password) == 0 )
        {
            print_welcome(username);
            return students[j].student_id;
        }
    }

    return FALSE;
}

// This function tokenizes login command
int login_command(char cmd[MAX_COMMAND_LENGTH],Student* students,int last_student_index)
{
    char* token = strtok(cmd, " ");
    //Skip the first token
    token = strtok(NULL, " ");
    
    char username[MAX_STR_LEN];
    char password[MAX_STR_LEN];

    int i = 0;
    while (token) {

        switch(i)
        {
            case 0:
                strcpy(username,token);
                break;
            case 1:
                strcpy(password,token);
                break;
        }

        i += 1;
        token = strtok(NULL, " ");
    }

    return login(username,password,students,last_student_index);
}

/* Admin Section */
int add_hall(char name[MAX_STR_LEN],int hall_id,int capacity,Hall* halls,int last_hall_index)
{
    for(int j = 0; j <= last_hall_index;j++)
    {
        if(halls[j].hall_id == hall_id )
            return FALSE;
    }

    strcpy(halls[last_hall_index + 1].name,name);
    halls[last_hall_index + 1].hall_id = hall_id;
    halls[last_hall_index + 1].capacity = capacity;

    return TRUE;
}

int add_hall_command(char cmd[MAX_COMMAND_LENGTH],Hall* halls,int last_hall_index)
{
    char* token = strtok(cmd, " ");
    //Skip the first token
    token = strtok(NULL, " ");
    
    char name[MAX_STR_LEN];
    int hall_id;
    int capacity;

    int i = 0;
    while (token) {

        switch(i)
        {
            case 0:
                strcpy(name,token);
                break;
            case 1:
                hall_id = atoi(token);
                break;
            case 2:
                capacity = atoi(token);
                break;
        }

        i += 1;
        token = strtok(NULL, " ");
    }

    return add_hall(name,hall_id,capacity,halls,last_hall_index);
}

int add_food(char name[MAX_STR_LEN],int food_id,int price,int capacity,int hall_id,int day
            ,Food* foods,Hall* halls,int last_hall_index,int last_food_index)
{
    // Here we check if hall_id exists
    int hall_found = FALSE;
    for(int j = 0; j <= last_hall_index;j++)
    {
        if(halls[j].hall_id == hall_id )
        {
            hall_found = TRUE;
            break;
        }
    }
    if(hall_found == FALSE)
    {
        print_wrong_hall_id();
        return FALSE;
    }
    
    // Here we check if food_id exists
    for(int j = 0; j <= last_food_index;j++)
    {
        if(foods[j].food_id == food_id)
        {
            print_not_unique_food_id();
            return FALSE;
        }
    }

    strcpy(foods[last_food_index + 1].name,name);
    foods[last_food_index + 1].food_id = food_id;
    foods[last_food_index + 1].price = price;
    foods[last_food_index + 1].capacity = capacity;
    foods[last_food_index + 1].hall_id = hall_id;
    foods[last_food_index + 1].day = day;

    return TRUE;
}

int add_food_command(char cmd[MAX_COMMAND_LENGTH],Food* foods,Hall* halls,int last_hall_index,int last_food_index)
{
    char* token = strtok(cmd, " ");
    //Skip the first token
    token = strtok(NULL, " ");
    
    char name[MAX_STR_LEN];
    int food_id;
    int price;
    int capacity;
    int hall_id;
    int day;

    int i = 0;
    while (token) {

        switch(i)
        {
            case 0:
                strcpy(name,token);
                break;
            case 1:
                food_id = atoi(token);
                break;
            case 2:
                price = atoi(token);
                break;
            case 3:
                capacity = atoi(token);
                break;
            case 4:
                hall_id = atoi(token);
                break;
            case 5:
                day = atoi(token);
                break;
        }

        i += 1;
        token = strtok(NULL, " ");
    }

    return add_food(name,food_id,price,capacity,hall_id,day,foods,halls,last_hall_index,last_food_index);
}

int add_coupon(int coupon_id,int percentage,int capacity,Coupon* coupons,int last_coupon_index)
{
    for(int j = 0; j <= last_coupon_index;j++)
    {
        if(coupons[j].coupon_id == coupon_id )
            return FALSE;
    }

    coupons[last_coupon_index + 1].coupon_id = coupon_id;
    coupons[last_coupon_index + 1].percentage = percentage;
    coupons[last_coupon_index + 1].capacity = capacity;

    return TRUE;
}

int add_coupon_command(char cmd[MAX_COMMAND_LENGTH],Coupon* coupons,int last_coupon_index)
{
    char* token = strtok(cmd, " ");
    //Skip the first token
    token = strtok(NULL, " ");

    int coupon_id;
    int percentage;
    int capacity;

    int i = 0;
    while (token) {

        switch(i)
        {
            case 0:
                coupon_id = atoi(token);
                break;
            case 1:
                percentage = atoi(token);
                break;
            case 2:
                capacity = atoi(token);
                break;
        }

        i += 1;
        token = strtok(NULL, " ");
    }

    return add_coupon(coupon_id,percentage,capacity,coupons,last_coupon_index);
}

Student* malloc_students(Student* students,int last_student_index)
{
    Student* new_ptr = malloc((last_student_index+2) * sizeof *students);
    for(int j = 0; j <= last_student_index;j++)
    {
        strcpy(new_ptr[j].username,students[j].username);
        strcpy(new_ptr[j].password,students[j].password);
        new_ptr[j].student_id = students[j].student_id;
    }

    return new_ptr;
}

Hall* malloc_halls(Hall* halls,int last_hall_index)
{
    Hall* new_ptr = malloc((last_hall_index+2) * sizeof *halls);
    for(int j = 0; j <= last_hall_index;j++)
    {
        strcpy(new_ptr[j].name,halls[j].name);
        new_ptr[j].hall_id = halls[j].hall_id;
        new_ptr[j].capacity = halls[j].capacity;
    }

    return new_ptr;
}

Food* malloc_foods(Food* foods,int last_food_index)
{
    Food* new_ptr = malloc((last_food_index+2) * sizeof *foods);
    for(int j = 0; j <= last_food_index;j++)
    {
        strcpy(new_ptr[j].name,foods[j].name);
        new_ptr[j].food_id = foods[j].food_id;
        new_ptr[j].price = foods[j].price;
        new_ptr[j].capacity = foods[j].capacity;
        new_ptr[j].hall_id = foods[j].hall_id;
        new_ptr[j].day = foods[j].day;
    }

    return new_ptr;
}

Coupon* malloc_coupon(Coupon* coupons,int last_coupon_index)
{
    Coupon* new_ptr = malloc((last_coupon_index+2) * sizeof *coupons);
    for(int j = 0; j <= last_coupon_index;j++)
    {
        new_ptr[j].coupon_id = coupons[j].coupon_id;
        new_ptr[j].percentage = coupons[j].percentage;
        new_ptr[j].capacity = coupons[j].capacity;
    }

    return new_ptr;
}


void run(Student* students,Hall* halls,Food* foods,Coupon* coupons,int last_student_index)
{
    // Current logged in user student_id
    int logged_in_user = NOT_SIGNED_IN;

    // Last indices
    int last_hall_index = -1;
    int last_food_index = -1;
    int last_coupon_index = -1;


    while(TRUE)
    {
        char cmd[MAX_COMMAND_LENGTH] = "";

        fgets(cmd, MAX_COMMAND_LENGTH, stdin); // read from stdin
        
        if(!is_empty(cmd))
            // Remove Next Line(\n)
            cmd[strcspn(cmd, "\n")] = 0;

        char cmd_copy[MAX_COMMAND_LENGTH];
        strcpy(cmd_copy,cmd);

        char *p = strtok(cmd_copy, " ");

        // Signup/Login Commands
        if(logged_in_user == NOT_SIGNED_IN)
        {
            //Signup command
            if(strcmp(p, SIGNUP) == 0)
            {
                if(signup_command(cmd,students,last_student_index) == TRUE)
                {
                    last_student_index += 1;
                    // Allocating more memory
                    students = malloc_students(students,last_student_index);
                    print_done();
                }
                else
                    print_user_already_exists();
            }
            //Login command
            else if(strcmp(p, LOGIN) == 0)
            {
                int log = login_command(cmd,students,last_student_index);
                if(log == FALSE)
                    print_wrong_user_pass();
                else
                    logged_in_user = log;
            }
            else
            {
                print_access_denied();
            }
        }
        // Admin Commands
        else if(logged_in_user == ADMIN_ID)
        {
            //Logout command
            if(strcmp(p, LOGOUT) == 0)
            {
                logged_in_user = NOT_SIGNED_IN;
                print_done();
            }
            //Add Hall
            else if(strcmp(p, ADD_HALL) == 0)
            {
                if(add_hall_command(cmd,halls,last_hall_index) == TRUE)
                {
                    last_hall_index += 1;
                    // Allocating more memory
                    halls = malloc_halls(halls,last_hall_index);
                    print_done();
                }
                else
                    print_not_unique_hall_id();
            }
            //Add Food
            else if(strcmp(p, ADD_FOOD) == 0)
            {
                if(add_food_command(cmd,foods,halls,last_hall_index,last_food_index) == TRUE)
                {
                    last_food_index += 1;
                    // Allocating more memory
                    foods = malloc_foods(foods,last_food_index);
                    print_done();
                }
            }
            //Add Coupon
            else if(strcmp(p, ADD_COUPON) == 0)
            {
                if(add_coupon_command(cmd,coupons,last_coupon_index) == TRUE)
                {
                    last_coupon_index += 1;
                    coupons = malloc_coupon(coupons,last_coupon_index);
                    print_done();
                }
                else
                {
                    print_not_unique_coupon_id();
                }
            }
            else
            {
                print_access_denied();
            }
        }
        // User Commands
        else
        {
            //Logout command
            if(strcmp(p, LOGOUT) == 0)
            {
                logged_in_user = NOT_SIGNED_IN;
                print_done();
            }
            else
            {
                print_access_denied();
            }


            /* Implement User Commands Here For Phase 2*/
        }
        
        
        continue;
    }
}

int file_exists (char *filename) {
    FILE *file;
    file = fopen(filename, "r");
    if (file) 
    {
        fclose(file);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int read_students(Student* students)
{
    int last_student_index = -1;
    // Create one if it doesn't exist
    if(file_exists(USERS_PATH) == FALSE)
    {
        FILE* file_ptr = fopen(USERS_PATH, "w");
        fclose(file_ptr);
    }
    else{
        FILE* fp = fopen(USERS_PATH,"r");

        char buffer[MAX_COMMAND_LENGTH];
        while (fgets(buffer, MAX_COMMAND_LENGTH, fp))
        {
            // Remove trailing newline
            buffer[strcspn(buffer, "\n")] = 0;

            char* token = strtok(buffer, " ");
            
            char username[MAX_STR_LEN];
            int student_id;
            char password[MAX_STR_LEN];

            int i = 0;
            while (token) {

                switch(i)
                {
                    case 0:
                        strcpy(username,token);
                        break;
                    case 1:
                        student_id = atoi(token);
                        break;
                    case 2:
                        strcpy(password,token);
                        break;
                }

                i += 1;
                token = strtok(NULL, " ");
            }

            int save_result = FALSE;
            signup(username,student_id,password,students,last_student_index,save_result);

            last_student_index += 1;
        }

        fclose(fp);
    }

    return last_student_index;
}

int main()
{
    Student* students = malloc(MAX_STUDENTS * sizeof *students);
    Hall* halls = malloc(MAX_HALL * sizeof *halls);
    Food* foods = malloc(MAX_FOOD * sizeof *foods);
    Coupon* coupons = malloc(MAX_COUPONS * sizeof *coupons);

    int last_student_index = read_students(students);

    run(students,halls,foods,coupons,last_student_index);
    
    return 0;
}